# Kocie Czasowniki (CatEnglishApp)

Offline aplikacja Android do nauki 150 angielskich czasowników nieregularnych,
oparta o 10-dniowy plan nauki, lokalną bazę Room/SQLite, dwa powiadomienia
dziennie i motyw kocio-fioletowo-zielony. **Zero zapytań sieciowych** — apka
nie deklaruje nawet uprawnienia `INTERNET`.

## Zawartość projektu

```
CatEnglishApp/
├── Dockerfile                  <- reprodukowalne środowisko budowania (SDK + Gradle)
├── docker-entrypoint.sh
├── build.gradle.kts / settings.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/verbs.json        <- 150 czasowników, 3 kategorie
│       ├── java/com/catenglish/app/
│       │   ├── CatEnglishApplication.kt
│       │   ├── data/                <- Room: encje, DAO, baza, seeder
│       │   ├── notifications/       <- AlarmManager (2x dziennie) + reboot receiver
│       │   ├── learning/            <- silnik quizu, spaced repetition, plan 10-dniowy
│       │   ├── audio/               <- AudioPlayer (lokalne pliki + offline TTS)
│       │   ├── admin/               <- panel administratora chroniony hasłem
│       │   └── ui/                  <- MainActivity + wszystkie ekrany
│       └── res/                     <- layouty, kolory fiolet/zieleń, wektory kotów
```

## 1. Krok wymagany przed pierwszym buildem: Gradle Wrapper JAR

Ze względów bezpieczeństwa nie dołączam binarnego pliku `gradle-wrapper.jar`
(to plik binarny pobierany normalnie z serwerów Gradle). Wygeneruj go raz,
na dowolnej maszynie z zainstalowanym Gradle:

```bash
cd CatEnglishApp
gradle wrapper --gradle-version 8.7
```

To utworzy `gradlew`, `gradlew.bat` i `gradle/wrapper/gradle-wrapper.jar`.
Zrób to raz — potem cały build jest już w pełni zdockeryzowany i offline
(Docker pobierze Gradle 8.7 i Android SDK 34 tylko raz, przy budowie obrazu).

## 2. Budowanie obrazu Dockera

```bash
docker build -t catenglish-builder .
```

To zbuduje obraz z Android SDK (platform 34, build-tools 34.0.0) i Gradle,
w wersjach dokładnie przypiętych w Dockerfile — build będzie identyczny na
każdej maszynie hosta.

## 3. Kompilacja APK

**Debug APK** (do testów, instalowalny bez podpisu produkcyjnego):

```bash
docker run --rm \
  -v "$(pwd)":/project \
  -v "$(pwd)/build-output":/output \
  catenglish-builder debug
```

APK pojawi się w `./build-output/app-debug.apk`.

**Release APK** (niepodpisany, do dystrybucji):

```bash
docker run --rm \
  -v "$(pwd)":/project \
  -v "$(pwd)/build-output":/output \
  catenglish-builder release
```

### Podpisanie release APK

```bash
# 1) Wygeneruj klucz (raz):
keytool -genkey -v -keystore catenglish.keystore -alias catenglish \
  -keyalg RSA -keysize 2048 -validity 10000

# 2) Podpisz (apksigner jest w Android SDK build-tools):
apksigner sign --ks catenglish.keystore \
  --out build-output/app-release-signed.apk \
  build-output/app-release-unsigned.apk

# 3) Zweryfikuj:
apksigner verify build-output/app-release-signed.apk
```

## 4. Instalacja na telefonie

```bash
adb install build-output/app-debug.apk
```

lub przenieś plik `.apk` na telefon i zainstaluj ręcznie (wymaga włączenia
"Instalacja z nieznanych źródeł").

## 5. WAŻNE: pliki audio nagród

Utwory takie jak "Firma - JP na 100%" i "We Are The Champions" są utworami
chronionymi prawem autorskim — nie są i nie mogą być dołączone do tego
repozytorium. Aplikacja jest w pełni przygotowana do ich odtwarzania: wystarczy
umieścić własne, legalnie posiadane pliki pod dokładnie tymi ścieżkami:

```
app/src/main/res/raw/reward_track_daily.mp3   <- pętla/refren po zaliczonym mini-egzaminie
app/src/main/res/raw/reward_track_boss.mp3    <- utwór zwycięstwa po pokonaniu Bossa
```

Bez tych plików aplikacja po prostu nie odtworzy dźwięku (zero crasha) —
slogan motywacyjny i tak się wyświetli. Wymowa czasowników (`verb_<base>.mp3`)
jest opcjonalna: bez plików audio aplikacja automatycznie użyje wbudowanego,
w pełni offline'owego silnika Android Text-to-Speech.

## 6. Panel administratora

Menu główne -> "Panel administratora" (dolny prawy róg) -> przy pierwszym
uruchomieniu poprosi o ustawienie hasła (hash PBKDF2 zapisywany lokalnie,
bez żadnej komunikacji sieciowej). W panelu można:
- ustawić dokładne godziny obu codziennych powiadomień,
- przełączyć slogany motywacyjne między trybem "street" a "grzecznym",
- zresetować 10-dniowy plan nauki.

## 7. Model danych / logika

- **150 czasowników** w `assets/verbs.json`, podzielonych na 3 grupy:
  `same_form` (bez zmiany formy, np. cut-cut-cut), `rhyming` (wzorzec
  samogłoskowy, np. swim-swam-swum), `classic` (pozostałe nieregularne).
- **Plan 10-dniowy**: dni 1-10 wprowadzają nowe czasowniki (rozkład sumujący
  się zawsze do dokładnie 150, patrz `DatabaseSeeder.assignToDays`).
- **Spaced repetition**: `QuizEngine` nagradza poprawne odpowiedzi (+20 do
  mastery), karze błędne (-25) i oznacza błędnie odpowiedziane czasowniki
  jako `needsRemedial`, dzięki czemu trafiają do puli powtórkowej następnego
  dnia — dokładnie jak w specyfikacji.
- **Główny Boss** odblokowuje się automatycznie od Dnia 10 (`DailyPlanManager`),
  próg zaliczenia to >= 90%.
