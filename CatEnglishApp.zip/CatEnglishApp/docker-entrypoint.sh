#!/usr/bin/env bash
set -euo pipefail

# Usage inside the container: docker-entrypoint.sh [debug|release]
BUILD_TYPE="${1:-debug}"

cd /project

echo "== Granting gradlew execute permission =="
chmod +x ./gradlew || true

if [ "$BUILD_TYPE" = "release" ]; then
    echo "== Building UNSIGNED release APK =="
    ./gradlew --no-daemon assembleRelease
    OUT_APK=$(find app/build/outputs/apk/release -name "*.apk" | head -n 1)
else
    echo "== Building debug APK =="
    ./gradlew --no-daemon assembleDebug
    OUT_APK=$(find app/build/outputs/apk/debug -name "*.apk" | head -n 1)
fi

if [ -z "${OUT_APK}" ]; then
    echo "Build failed: no APK produced." >&2
    exit 1
fi

mkdir -p /output
cp "${OUT_APK}" /output/
echo "== APK ready: /output/$(basename "${OUT_APK}") =="
