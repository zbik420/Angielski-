# Keep Room entities & DAOs
-keep class com.catenglish.app.data.** { *; }
-keepclassmembers class com.catenglish.app.data.** { *; }

# Keep WorkManager workers
-keep class com.catenglish.app.notifications.** { *; }

# General Room
-dontwarn androidx.room.paging.**
