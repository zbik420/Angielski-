Umieść tutaj własne, w pełni licencjonowane pliki audio o dokładnie tych nazwach:

  verb_<base>.mp3          np. verb_go.mp3, verb_swim.mp3 (opcjonalne - bez nich
                            aplikacja użyje lokalnego silnika Text-to-Speech)
  cat_meow_correct.mp3      krótki dźwięk poprawnej odpowiedzi (opcjonalny)
  cat_meow_wrong.mp3        krótki dźwięk błędnej odpowiedzi (opcjonalny)
  reward_track_daily.mp3    utwór/refren odtwarzany po zaliczonym mini-egzaminie
                            (WYMAGA własnej, licencjonowanej kopii - np. zakupionej
                            legalnie lub własnej kompozycji; nie mogę dostarczyć
                            treści chronionej prawem autorskim)
  reward_track_boss.mp3     utwór zwycięstwa po pokonaniu Głównego Bossa
                            (jw. - podłóż własny, licencjonowany plik)

Format: MP3 lub OGG, umieszczone bezpośrednio w tym folderze (res/raw), bez
podfolderów, nazwy plików wyłącznie małymi literami i podkreśleniami.
