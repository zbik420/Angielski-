package com.catenglish.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.R
import com.catenglish.app.audio.AudioPlayer
import com.catenglish.app.databinding.ActivityExamBinding
import com.catenglish.app.learning.QuizEngine
import com.catenglish.app.learning.QuizQuestion
import com.catenglish.app.learning.QuizResult
import kotlinx.coroutines.launch

/**
 * Shared exam-taking flow. Each question asks for Past Simple + Past Participle
 * (comma-separated) for the shown base verb. Used by both:
 *  - Session 2's daily mini-exam (ExamActivity)
 *  - The Główny Boss final exam (BossExamActivity)
 */
abstract class BaseExamActivity : AppCompatActivity() {

    protected lateinit var binding: ActivityExamBinding
    protected val db by lazy { (application as CatEnglishApplication).database }
    protected val quizEngine by lazy { QuizEngine(db) }
    protected lateinit var audioPlayer: AudioPlayer

    private var questions: List<QuizQuestion> = emptyList()
    private var currentIndex = 0
    private var correctCount = 0

    /** Subclasses supply their question set and pass threshold. */
    abstract suspend fun loadQuestions(): List<QuizQuestion>
    abstract val passThresholdPercent: Int
    abstract fun onExamFinished(correct: Int, total: Int, passed: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExamBinding.inflate(layoutInflater)
        setContentView(binding.root)
        audioPlayer = AudioPlayer(this)

        lifecycleScope.launch {
            questions = loadQuestions()
            if (questions.isEmpty()) {
                binding.examQuestionText.text = "Brak pytań do wyświetlenia."
                binding.examSubmitButton.isEnabled = false
                return@launch
            }
            showQuestion()
        }

        binding.examSubmitButton.setOnClickListener { submitAnswer() }
    }

    private fun showQuestion() {
        val q = questions.getOrNull(currentIndex) ?: return finishExam()
        binding.examProgressLabel.text = "Pytanie ${currentIndex + 1} / ${questions.size}"
        binding.examProgressBar.progress = ((currentIndex) * 100) / questions.size
        binding.examQuestionText.text = "${q.verb.base}\n(${q.verb.polish})"
        binding.examAnswerInput.text?.clear()
        binding.examFeedbackText.text = ""
    }

    private fun submitAnswer() {
        val q = questions.getOrNull(currentIndex) ?: return
        val raw = binding.examAnswerInput.text?.toString().orEmpty()
        val parts = raw.split(",").map { it.trim() }
        val pastGiven = parts.getOrNull(0).orEmpty()
        val participleGiven = parts.getOrNull(1).orEmpty()

        val correct = pastGiven.equals(q.verb.past, ignoreCase = true) &&
            participleGiven.equals(q.verb.participle, ignoreCase = true)

        if (correct) {
            correctCount++
            binding.examFeedbackText.setTextColor(getColor(R.color.green_dark))
            binding.examFeedbackText.text = "Dobrze! ✅"
        } else {
            binding.examFeedbackText.setTextColor(getColor(R.color.error_red))
            binding.examFeedbackText.text = "Poprawnie: ${q.verb.past}, ${q.verb.participle}"
        }

        lifecycleScope.launch {
            quizEngine.recordAnswer(QuizResult(q.verb.id, correct), currentDayForRecording())
        }

        binding.examSubmitButton.postDelayed({
            currentIndex++
            showQuestion()
        }, 1200)
    }

    protected open suspend fun currentDayForRecording(): Int {
        return db.configDao().getValue(com.catenglish.app.data.ConfigKeys.CURRENT_DAY)?.toIntOrNull() ?: 1
    }

    private fun finishExam() {
        val total = questions.size
        val passed = quizEngine.passed(correctCount, total, passThresholdPercent)
        onExamFinished(correctCount, total, passed)
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }
}
