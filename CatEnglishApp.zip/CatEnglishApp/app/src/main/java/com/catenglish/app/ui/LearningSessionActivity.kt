package com.catenglish.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.R
import com.catenglish.app.audio.AudioPlayer
import com.catenglish.app.data.VerbEntity
import com.catenglish.app.databinding.ActivityLearningSessionBinding
import com.catenglish.app.learning.DailyPlanManager
import kotlinx.coroutines.launch

/**
 * Session 1 (Morning, ~30 min): Acquisition.
 * Introduces the day's target verbs with audio, then a typing practice exercise
 * (type Past Simple + Past Participle) for each verb, per spec.
 */
class LearningSessionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLearningSessionBinding
    private val db by lazy { (application as CatEnglishApplication).database }
    private val planManager by lazy { DailyPlanManager(db) }
    private lateinit var audioPlayer: AudioPlayer

    private var todaysVerbs: List<VerbEntity> = emptyList()
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLearningSessionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        audioPlayer = AudioPlayer(this)
        title = "Sesja 1: Nauka"

        lifecycleScope.launch {
            val day = planManager.getCurrentDay()
            todaysVerbs = db.verbDao().getByAssignedDay(day)
            if (todaysVerbs.isEmpty()) {
                binding.verbBaseText.text = "Brak nowych czasowników na dziś 🎉"
                binding.checkButton.isEnabled = false
                return@launch
            }
            showVerb()
        }

        binding.speakerButton.setOnClickListener {
            todaysVerbs.getOrNull(currentIndex)?.let { audioPlayer.playVerb(it.base, it.audioFile) }
        }

        binding.checkButton.setOnClickListener { checkAnswer() }
    }

    private fun showVerb() {
        val verb = todaysVerbs.getOrNull(currentIndex) ?: return finishSession()
        binding.progressLabel.text = "Czasownik ${currentIndex + 1} / ${todaysVerbs.size}"
        binding.verbBaseText.text = verb.base
        binding.verbPolishText.text = verb.polish
        binding.pastInput.text?.clear()
        binding.participleInput.text?.clear()
        binding.feedbackText.text = ""
        audioPlayer.playVerb(verb.base, verb.audioFile)
    }

    private fun checkAnswer() {
        val verb = todaysVerbs.getOrNull(currentIndex) ?: return
        val pastOk = binding.pastInput.text?.toString()?.trim()?.equals(verb.past, ignoreCase = true) == true
        val participleOk = binding.participleInput.text?.toString()?.trim()
            ?.equals(verb.participle, ignoreCase = true) == true

        if (pastOk && participleOk) {
            binding.feedbackText.setTextColor(getColor(R.color.green_dark))
            binding.feedbackText.text = "Świetnie! ✅"
        } else {
            binding.feedbackText.setTextColor(getColor(R.color.error_red))
            binding.feedbackText.text = "Poprawna odpowiedź: ${verb.past} — ${verb.participle}"
        }

        binding.checkButton.postDelayed({
            currentIndex++
            showVerb()
        }, 1400)
    }

    private fun finishSession() {
        binding.verbBaseText.text = "Sesja 1 ukończona! 🐾"
        binding.pastInput.visibility = android.view.View.GONE
        binding.participleInput.visibility = android.view.View.GONE
        binding.checkButton.visibility = android.view.View.GONE
        binding.feedbackText.text = "Wróć wieczorem na mini-egzamin (Sesja 2)."
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }
}
