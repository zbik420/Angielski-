package com.catenglish.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ConfigDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(config: ConfigEntity)

    @Query("SELECT * FROM config WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): ConfigEntity?

    @Query("SELECT value FROM config WHERE `key` = :key LIMIT 1")
    suspend fun getValue(key: String): String?

    @Query("DELETE FROM config WHERE `key` = :key")
    suspend fun delete(key: String)
}
