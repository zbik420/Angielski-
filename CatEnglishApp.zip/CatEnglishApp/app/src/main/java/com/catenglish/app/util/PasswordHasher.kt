package com.catenglish.app.util

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Local-only password hashing for the Admin Panel. No network, no cloud auth —
 * the hash + salt are stored in the local `config` Room table.
 */
object PasswordHasher {

    private const val ITERATIONS = 12000
    private const val KEY_LENGTH = 256

    fun hash(password: String, saltHex: String? = null): String {
        val salt = if (saltHex != null) hexToBytes(saltHex) else ByteArray(16).also { SecureRandom().nextBytes(it) }
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hashBytes = factory.generateSecret(spec).encoded
        return "${bytesToHex(salt)}:${bytesToHex(hashBytes)}"
    }

    fun verify(password: String, stored: String): Boolean {
        val parts = stored.split(":")
        if (parts.size != 2) return false
        val (saltHex, _) = parts
        val recomputed = hash(password, saltHex)
        return MessageDigest.isEqual(recomputed.toByteArray(), stored.toByteArray())
    }

    private fun bytesToHex(bytes: ByteArray): String =
        bytes.joinToString("") { "%02x".format(it) }

    private fun hexToBytes(hex: String): ByteArray =
        ByteArray(hex.length / 2) { i -> ((Character.digit(hex[i * 2], 16) shl 4) + Character.digit(hex[i * 2 + 1], 16)).toByte() }
}
