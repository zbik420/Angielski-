package com.catenglish.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Handles ALL audio playback in the app — verb pronunciations, motivational
 * tracks, and boss-victory music. Everything is sourced from local assets
 * (res/raw) or the on-device TTS engine (which itself works fully offline
 * once its language pack is installed — no network calls are made by this class).
 *
 * Expected res/raw filenames:
 *   verb_<base>.mp3                 -> one per verb (optional; falls back to TTS if missing)
 *   reward_track_daily.mp3          -> looped chorus played after a passed daily mini-exam
 *   reward_track_boss.mp3           -> played after passing the Główny Boss final exam
 *   cat_meow_correct.mp3 / cat_meow_wrong.mp3 -> short UI feedback sounds
 *
 * IMPORTANT: "reward_track_daily.mp3" / "reward_track_boss.mp3" are placeholders.
 * Commercial songs (e.g. "Firma - JP na 100%", "We Are The Champions") are copyrighted
 * and must be supplied by you from a licensed source — drop the file at that exact
 * path/filename and this class will play it. Until then, playback simply no-ops safely.
 */
class AudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                ttsReady = true
            }
        }
    }

    /** Plays a verb's local audio file if bundled; otherwise falls back to on-device TTS. */
    fun playVerb(base: String, audioFileResName: String, onComplete: (() -> Unit)? = null) {
        val resId = context.resources.getIdentifier(audioFileResName, "raw", context.packageName)
        if (resId != 0) {
            playRawResource(resId, loop = false, onComplete = onComplete)
        } else {
            speak(base, onComplete)
        }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        val engine = tts ?: return
        if (!ttsReady) return
        val utteranceId = "utt_${System.currentTimeMillis()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                onComplete?.invoke()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun playShortSfx(rawResName: String) {
        val resId = context.resources.getIdentifier(rawResName, "raw", context.packageName)
        if (resId != 0) playRawResource(resId, loop = false)
    }

    /** Reward track after a passed daily mini-exam. Loops the chorus per spec. */
    fun playDailyRewardTrack() {
        val resId = context.resources.getIdentifier("reward_track_daily", "raw", context.packageName)
        if (resId != 0) playRawResource(resId, loop = true)
    }

    /** Victory track after passing the Główny Boss final exam. */
    fun playBossVictoryTrack() {
        val resId = context.resources.getIdentifier("reward_track_boss", "raw", context.packageName)
        if (resId != 0) playRawResource(resId, loop = false)
    }

    fun stop() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
    }

    private fun playRawResource(resId: Int, loop: Boolean, onComplete: (() -> Unit)? = null) {
        stop()
        mediaPlayer = MediaPlayer.create(context, resId)?.apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            isLooping = loop
            setOnCompletionListener {
                if (!loop) onComplete?.invoke()
            }
            start()
        }
    }

    fun release() {
        stop()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
