package com.catenglish.app.ui

import android.content.Intent
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.learning.DailyPlanManager
import com.catenglish.app.learning.QuizEngine
import com.catenglish.app.learning.QuizQuestion
import kotlinx.coroutines.launch

/**
 * Session 2 (Evening, ~25 min): Daily Mini-Exam.
 * Tests today's 15 verbs + 10-15 spaced-repetition verbs from previous days.
 * On pass: advances the 10-day plan, triggers the motivational reward screen.
 */
class ExamActivity : BaseExamActivity() {

    private val planManager by lazy { DailyPlanManager(db) }

    override val passThresholdPercent = QuizEngine.DAILY_EXAM_PASS_THRESHOLD

    override suspend fun loadQuestions(): List<QuizQuestion> {
        val day = planManager.getCurrentDay()
        return quizEngine.buildDailyMiniExam(day)
    }

    override fun onExamFinished(correct: Int, total: Int, passed: Boolean) {
        lifecycleScope.launch {
            if (passed) {
                planManager.advanceDayIfEligible()
            }
            val intent = Intent(this@ExamActivity, RewardActivity::class.java).apply {
                putExtra(RewardActivity.EXTRA_CORRECT, correct)
                putExtra(RewardActivity.EXTRA_TOTAL, total)
                putExtra(RewardActivity.EXTRA_PASSED, passed)
                putExtra(RewardActivity.EXTRA_IS_BOSS, false)
            }
            startActivity(intent)
            finish()
        }
    }
}
