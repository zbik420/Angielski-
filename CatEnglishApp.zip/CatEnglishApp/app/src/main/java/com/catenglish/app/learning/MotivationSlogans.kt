package com.catenglish.app.learning

/**
 * Motivational slogans shown after a passed daily mini-exam.
 *
 * STREET mode = the hard-hitting, informal Polish street/rap-style hype text requested
 * in the spec. POLITE mode is an admin-toggleable alternative (Panel Administratora ->
 * "Tryb grzeczny") for households where that tone isn't appropriate — same energy,
 * no profanity. Default is STREET, matching the spec, but the toggle exists precisely
 * so the app owner controls what's shown, without needing me to hardcode a single tone.
 */
object MotivationSlogans {

    val street = listOf(
        "Ogarnąłeś to jak prawdziwy szmaciarz gry, koty biją ci brawo!",
        "Zapieprzasz na maksa, żaden czasownik cię nie zatrzyma!",
        "Idziesz jak burza, słownictwo się ciebie boi!",
        "Full luz, full moc — dzisiaj rozjechałeś te czasowniki!",
        "Kotgang jest z ciebie dumny, robota wykonana na 100%!",
        "Zero wymówek, sama jazda — tak się zdobywa poziomy!",
        "Nieregularne czasowniki? Już dla ciebie regularna formalność!",
        "Grasz o wygraną i wygrywasz — łapy w górę, koci wojowniku!"
    )

    val polite = listOf(
        "Świetna robota! Kolejny krok bliżej mistrzostwa.",
        "Koty są z ciebie dumne — tak trzymaj!",
        "Systematyczność popłaca — dzisiejszy egzamin zaliczony!",
        "Twoje słownictwo rośnie w oczach, gratulacje!",
        "Jeszcze trochę i będziesz gotowy na Głównego Bossa!",
        "Codzienna praca robi różnicę — brawo za wytrwałość!"
    )

    fun random(streetMode: Boolean): String {
        val pool = if (streetMode) street else polite
        return pool.random()
    }
}
