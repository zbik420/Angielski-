package com.catenglish.app.data

import android.content.Context
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Reads the 150 verbs bundled in assets/verbs.json (fully offline, no network)
 * and seeds Room on first launch only. Also assigns each verb to a day (1..10)
 * of the learning plan:
 *
 *   Days 1-7  -> 15 new verbs/day  (7 * 15 = 105)
 *   Days 8-10 -> 15 new verbs/day  (3 * 15 = 45)   [total 150]
 *
 * Note: spec calls for "15/day days 1-7, scaling down to 10 on days 8-10" for the
 * ACQUISITION workload, while total verb count is fixed at 150. To reconcile a fixed
 * 150-verb bank with a lighter 8-10 day workload, days 8-10 introduce 10 NEW verbs/day
 * (30 total) and the remaining 15 verbs are folded into those days as spaced-repetition
 * review-only items (already introduced isn't required, but here we distribute the
 * bank as 15/15/15/15/15/15/15/10/10/10 = 135... to guarantee exactly 150 across 10 days
 * we use 15,15,15,15,15,15,15,10,10,15 style balancing computed programmatically below,
 * so the *exact* daily counts always sum to 150 regardless of future edits to verbs.json.
 */
class DatabaseSeeder(
    private val context: Context,
    private val db: AppDatabase
) {

    suspend fun seedIfNeeded() {
        val configDao = db.configDao()
        val alreadySeeded = configDao.getValue(ConfigKeys.DB_SEEDED) == "true"
        if (alreadySeeded) return

        val verbs = loadVerbsFromAssets()
        val withDays = assignToDays(verbs)

        db.verbDao().insertAll(withDays)
        db.progressDao().insertAll(
            withDays.map { verb ->
                UserProgressEntity(
                    verbId = verb.id,
                    introducedOnDay = verb.assignedDay
                )
            }
        )

        configDao.set(ConfigEntity(ConfigKeys.DB_SEEDED, "true"))
        configDao.set(ConfigEntity(ConfigKeys.CURRENT_DAY, "1"))
        configDao.set(ConfigEntity(ConfigKeys.BOSS_UNLOCKED, "false"))
        configDao.set(
            ConfigEntity(ConfigKeys.PROGRAM_START_EPOCH_DAY, (System.currentTimeMillis() / 86_400_000L).toString())
        )
    }

    private fun loadVerbsFromAssets(): List<VerbEntity> {
        val json = context.assets.open("verbs.json").use { stream ->
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
        }
        val array = JSONArray(json)
        val result = ArrayList<VerbEntity>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(
                VerbEntity(
                    id = obj.getInt("id"),
                    base = obj.getString("base"),
                    past = obj.getString("past"),
                    participle = obj.getString("participle"),
                    polish = obj.getString("polish"),
                    group = obj.getString("group"),
                    groupName = obj.getString("groupName"),
                    audioFile = obj.getString("audioFile")
                )
            )
        }
        return result
    }

    /**
     * Distributes N verbs across a 10-day plan following the target daily quota shape
     * from the spec: heavier at the start (15/day), lighter at the end (10/day),
     * while always summing exactly to N (150 in the default asset bundle).
     */
    private fun assignToDays(verbs: List<VerbEntity>): List<VerbEntity> {
        val total = verbs.size
        val baseQuota = intArrayOf(15, 15, 15, 15, 15, 15, 15, 10, 10, 10) // sums to 135 by default
        val quotas = baseQuota.copyOf()

        // Distribute any remainder (e.g. if verbs.json is edited later) across the last days.
        var assigned = quotas.sum()
        var dayCursor = 9 // 0-indexed day 10
        while (assigned < total) {
            quotas[dayCursor] += 1
            assigned++
            dayCursor -= 1
            if (dayCursor < 0) dayCursor = 9
        }
        // If total is smaller than the base quota sum, shrink from the end days first.
        dayCursor = 9
        while (assigned > total) {
            if (quotas[dayCursor] > 0) {
                quotas[dayCursor] -= 1
                assigned--
            }
            dayCursor -= 1
            if (dayCursor < 0) dayCursor = 9
        }

        // Interleave groups so each day mixes same_form / rhyming / classic verbs
        // rather than dumping one whole category on day 1.
        val bucketed = verbs.groupBy { it.group }
        val ordered = ArrayList<VerbEntity>(total)
        val iterators = bucketed.values.map { it.iterator() }.toMutableList()
        while (ordered.size < total) {
            var progressed = false
            for (it in iterators) {
                if (it.hasNext()) {
                    ordered.add(it.next())
                    progressed = true
                }
            }
            if (!progressed) break
        }

        var index = 0
        val result = ArrayList<VerbEntity>(total)
        for (day in 1..10) {
            val quota = quotas[day - 1]
            repeat(quota) {
                if (index < ordered.size) {
                    result.add(ordered[index].copy(assignedDay = day))
                    index++
                }
            }
        }
        return result
    }
}
