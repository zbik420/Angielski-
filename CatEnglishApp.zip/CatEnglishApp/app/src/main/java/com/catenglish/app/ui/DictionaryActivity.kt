package com.catenglish.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.audio.AudioPlayer
import com.catenglish.app.data.VerbEntity
import com.catenglish.app.databinding.ActivityDictionaryBinding
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch

class DictionaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDictionaryBinding
    private val db by lazy { (application as CatEnglishApplication).database }
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var adapter: VerbAdapter

    private var allVerbs: List<VerbEntity> = emptyList()
    private var currentGroupFilter: String? = null // null = all
    private var currentQuery: String = ""

    private val groups = listOf(
        null to "Wszystkie",
        "same_form" to "Bez zmian",
        "rhyming" to "Rymujące się",
        "classic" to "Klasyczne"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDictionaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        audioPlayer = AudioPlayer(this)

        adapter = VerbAdapter(emptyList()) { verb -> audioPlayer.playVerb(verb.base, verb.audioFile) }
        binding.verbsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.verbsRecyclerView.adapter = adapter

        groups.forEach { (key, label) ->
            binding.groupTabs.addTab(binding.groupTabs.newTab().setText(label).setTag(key))
        }
        binding.groupTabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentGroupFilter = tab.tag as String?
                applyFilters()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString().orEmpty()
                applyFilters()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        lifecycleScope.launch {
            allVerbs = db.verbDao().getAll()
            applyFilters()
        }
    }

    private fun applyFilters() {
        var filtered = allVerbs
        currentGroupFilter?.let { group -> filtered = filtered.filter { it.group == group } }
        if (currentQuery.isNotBlank()) {
            val q = currentQuery.lowercase()
            filtered = filtered.filter {
                it.base.lowercase().contains(q) || it.polish.lowercase().contains(q)
            }
        }
        adapter.updateData(filtered)
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }
}
