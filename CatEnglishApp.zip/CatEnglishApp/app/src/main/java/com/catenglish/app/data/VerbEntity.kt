package com.catenglish.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One of the 150 irregular verbs, seeded once from assets/verbs.json.
 *
 * group values:
 *  - "same_form" : base = past = participle (e.g. cut-cut-cut)   -> ~30 verbs
 *  - "rhyming"   : vowel-shift pattern (e.g. swim-swam-swum)      -> ~30 verbs
 *  - "classic"   : irregular, no shared pattern (e.g. go-went-gone) -> ~90 verbs
 */
@Entity(tableName = "verbs")
data class VerbEntity(
    @PrimaryKey val id: Int,
    val base: String,
    val past: String,
    val participle: String,
    val polish: String,
    val group: String,
    val groupName: String,
    val audioFile: String,
    // which of the 10 learning days this verb is first introduced on (1..10), assigned by DailyPlanManager
    val assignedDay: Int = 0
)
