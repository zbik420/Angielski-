package com.catenglish.app.admin

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.data.ConfigEntity
import com.catenglish.app.data.ConfigKeys
import com.catenglish.app.databinding.ActivityAdminPanelBinding
import com.catenglish.app.notifications.NotificationScheduler
import kotlinx.coroutines.launch

/**
 * Password-protected admin screen (reached only via AdminLoginActivity).
 * Lets the app owner configure:
 *   - Exact hour/minute for the 2 daily local notifications
 *   - Street vs. Polite motivational slogan mode
 *   - Reset of the 10-day program (for testing / restarting a learner)
 */
class AdminPanelActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminPanelBinding
    private val db by lazy { (application as CatEnglishApplication).database }
    private val scheduler by lazy { NotificationScheduler(this) }

    private var morningHour = ConfigKeys.DEFAULT_MORNING_HOUR
    private var morningMinute = ConfigKeys.DEFAULT_MORNING_MINUTE
    private var eveningHour = ConfigKeys.DEFAULT_EVENING_HOUR
    private var eveningMinute = ConfigKeys.DEFAULT_EVENING_MINUTE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminPanelBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = getString(com.catenglish.app.R.string.admin_panel_title)

        loadCurrentConfig()

        binding.morningTimeButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                morningHour = h; morningMinute = m
                binding.morningTimeButton.text = "Sesja 1 (rano): %02d:%02d".format(h, m)
            }, morningHour, morningMinute, true).show()
        }

        binding.eveningTimeButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                eveningHour = h; eveningMinute = m
                binding.eveningTimeButton.text = "Sesja 2 (wieczór): %02d:%02d".format(h, m)
            }, eveningHour, eveningMinute, true).show()
        }

        binding.saveButton.setOnClickListener {
            lifecycleScope.launch {
                scheduler.updateTimes(morningHour, morningMinute, eveningHour, eveningMinute)
                db.configDao().set(
                    ConfigEntity("street_slogans_enabled", binding.streetModeSwitch.isChecked.toString())
                )
                Toast.makeText(this@AdminPanelActivity, "Zapisano ustawienia", Toast.LENGTH_SHORT).show()
            }
        }

        binding.resetProgressButton.setOnClickListener {
            lifecycleScope.launch {
                db.configDao().set(ConfigEntity(ConfigKeys.CURRENT_DAY, "1"))
                db.configDao().set(ConfigEntity(ConfigKeys.BOSS_UNLOCKED, "false"))
                Toast.makeText(this@AdminPanelActivity, "Zresetowano postęp 10-dniowego planu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadCurrentConfig() {
        lifecycleScope.launch {
            val configDao = db.configDao()
            morningHour = configDao.getValue(ConfigKeys.NOTIF_MORNING_HOUR)?.toIntOrNull() ?: ConfigKeys.DEFAULT_MORNING_HOUR
            morningMinute = configDao.getValue(ConfigKeys.NOTIF_MORNING_MINUTE)?.toIntOrNull() ?: ConfigKeys.DEFAULT_MORNING_MINUTE
            eveningHour = configDao.getValue(ConfigKeys.NOTIF_EVENING_HOUR)?.toIntOrNull() ?: ConfigKeys.DEFAULT_EVENING_HOUR
            eveningMinute = configDao.getValue(ConfigKeys.NOTIF_EVENING_MINUTE)?.toIntOrNull() ?: ConfigKeys.DEFAULT_EVENING_MINUTE
            val streetMode = configDao.getValue("street_slogans_enabled")?.toBooleanStrictOrNull() ?: true

            binding.morningTimeButton.text = "Sesja 1 (rano): %02d:%02d".format(morningHour, morningMinute)
            binding.eveningTimeButton.text = "Sesja 2 (wieczór): %02d:%02d".format(eveningHour, eveningMinute)
            binding.streetModeSwitch.isChecked = streetMode
        }
    }
}
