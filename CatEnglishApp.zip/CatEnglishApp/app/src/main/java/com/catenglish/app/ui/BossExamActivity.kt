package com.catenglish.app.ui

import android.content.Intent
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.learning.QuizEngine
import com.catenglish.app.learning.QuizQuestion
import kotlinx.coroutines.launch

/**
 * "Główny Boss" - the final exam covering all 150 verbs, unlocked only from Day 10.
 * Pass threshold: >= 90% (per spec). Success triggers the victory screen + track.
 */
class BossExamActivity : BaseExamActivity() {

    override val passThresholdPercent = QuizEngine.BOSS_EXAM_PASS_THRESHOLD

    override suspend fun loadQuestions(): List<QuizQuestion> {
        return quizEngine.buildBossExam()
    }

    override fun onExamFinished(correct: Int, total: Int, passed: Boolean) {
        lifecycleScope.launch {
            val intent = Intent(this@BossExamActivity, RewardActivity::class.java).apply {
                putExtra(RewardActivity.EXTRA_CORRECT, correct)
                putExtra(RewardActivity.EXTRA_TOTAL, total)
                putExtra(RewardActivity.EXTRA_PASSED, passed)
                putExtra(RewardActivity.EXTRA_IS_BOSS, true)
            }
            startActivity(intent)
            finish()
        }
    }
}
