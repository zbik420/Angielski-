package com.catenglish.app.learning

import com.catenglish.app.data.AppDatabase
import com.catenglish.app.data.UserProgressEntity
import com.catenglish.app.data.VerbEntity
import kotlin.random.Random

data class QuizQuestion(
    val verb: VerbEntity,
    val isReview: Boolean // true = spaced-repetition cross-test item from a previous day
)

data class QuizResult(
    val verbId: Int,
    val wasCorrect: Boolean
)

/**
 * Core spaced-repetition + scoring logic used by:
 *  - Session 1 acquisition practice (typing / matching)
 *  - Session 2 daily mini-exam (today's 15 verbs + 10-15 random verbs from previous days)
 *  - Główny Boss final exam (all 150 verbs)
 *
 * Mastery model (simple, deterministic, fully local — no ML/network needed):
 *  - Correct answer:  +20 mastery (capped at 100), consecutiveCorrect++
 *  - Wrong answer:    -25 mastery (floored at 0), consecutiveCorrect = 0, needsRemedial = true
 *  - isMastered flips true once masteryScore >= MASTERY_THRESHOLD (90) AND consecutiveCorrect >= 2
 */
class QuizEngine(private val db: AppDatabase) {

    /** Builds Session 2's mini-exam: today's new verbs + a spaced-repetition sample from earlier days. */
    suspend fun buildDailyMiniExam(currentDay: Int): List<QuizQuestion> {
        val todayVerbs = db.verbDao().getByAssignedDay(currentDay)
        val reviewCandidates = db.progressDao().getReviewCandidates(currentDay)

        // Prioritize verbs the learner previously got wrong (remedial pool) for cross-testing.
        val remedialIds = reviewCandidates.filter { it.needsRemedial }.map { it.verbId }.toSet()
        val otherIds = reviewCandidates.map { it.verbId }.filterNot { it in remedialIds }

        val reviewCount = (10..15).random()
        val chosenRemedial = remedialIds.shuffled().take(reviewCount)
        val remainingSlots = (reviewCount - chosenRemedial.size).coerceAtLeast(0)
        val chosenOthers = otherIds.shuffled().take(remainingSlots)
        val reviewIds = (chosenRemedial + chosenOthers).toSet()

        val reviewVerbs = reviewIds.mapNotNull { db.verbDao().getById(it) }

        val questions = ArrayList<QuizQuestion>()
        questions += todayVerbs.map { QuizQuestion(it, isReview = false) }
        questions += reviewVerbs.map { QuizQuestion(it, isReview = true) }
        return questions.shuffled()
    }

    /** Builds the Główny Boss final exam: all 150 verbs, shuffled. */
    suspend fun buildBossExam(): List<QuizQuestion> {
        return db.verbDao().getAll().shuffled().map { QuizQuestion(it, isReview = true) }
    }

    /** Records one answer and updates the spaced-repetition mastery record for that verb. */
    suspend fun recordAnswer(result: QuizResult, currentDay: Int) {
        val dao = db.progressDao()
        val existing = dao.getForVerb(result.verbId) ?: UserProgressEntity(
            verbId = result.verbId,
            introducedOnDay = currentDay
        )

        val todayEpochDay = System.currentTimeMillis() / 86_400_000L

        val updated = if (result.wasCorrect) {
            val newScore = (existing.masteryScore + 20).coerceAtMost(100)
            val newStreak = existing.consecutiveCorrect + 1
            existing.copy(
                masteryScore = newScore,
                consecutiveCorrect = newStreak,
                timesSeen = existing.timesSeen + 1,
                lastReviewedEpochDay = todayEpochDay,
                isMastered = newScore >= UserProgressEntity.MASTERY_THRESHOLD && newStreak >= 2,
                needsRemedial = false
            )
        } else {
            val newScore = (existing.masteryScore - 25).coerceAtLeast(0)
            existing.copy(
                masteryScore = newScore,
                consecutiveCorrect = 0,
                timesSeen = existing.timesSeen + 1,
                timesWrong = existing.timesWrong + 1,
                lastReviewedEpochDay = todayEpochDay,
                isMastered = false,
                needsRemedial = true // pushed into next day's remedial pool, per spec
            )
        }
        dao.update(updated)
    }

    /** Global retention percentage shown on the main screen (drives the cat graphic stage). */
    suspend fun globalRetentionPercent(): Int {
        val totalVerbs = db.verbDao().count()
        if (totalVerbs == 0) return 0
        val sumMastery = db.progressDao().sumMastery()
        val maxPossible = totalVerbs * 100
        return ((sumMastery.toDouble() / maxPossible) * 100).toInt().coerceIn(0, 100)
    }

    /** Exam pass threshold check, e.g. for the Główny Boss (>= 90%) or daily mini-exam (>= 80%). */
    fun passed(correctCount: Int, totalCount: Int, thresholdPercent: Int): Boolean {
        if (totalCount == 0) return false
        val pct = (correctCount * 100) / totalCount
        return pct >= thresholdPercent
    }

    companion object {
        const val DAILY_EXAM_PASS_THRESHOLD = 80
        const val BOSS_EXAM_PASS_THRESHOLD = 90
    }
}

/** Simple exercise-type picker used by Session 1 (acquisition practice). */
enum class ExerciseType { TYPING, MATCHING }

fun randomExerciseType(): ExerciseType =
    if (Random.nextBoolean()) ExerciseType.TYPING else ExerciseType.MATCHING
