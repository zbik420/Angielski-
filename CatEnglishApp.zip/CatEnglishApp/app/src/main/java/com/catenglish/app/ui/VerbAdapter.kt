package com.catenglish.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.catenglish.app.data.VerbEntity
import com.catenglish.app.databinding.ItemVerbBinding

class VerbAdapter(
    private var items: List<VerbEntity>,
    private val onSpeakerClick: (VerbEntity) -> Unit
) : RecyclerView.Adapter<VerbAdapter.VH>() {

    inner class VH(val binding: ItemVerbBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemVerbBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val verb = items[position]
        holder.binding.verbForms.text = "${verb.base} — ${verb.past} — ${verb.participle}"
        holder.binding.verbPolish.text = verb.polish
        holder.binding.speakerButton.setOnClickListener { onSpeakerClick(verb) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<VerbEntity>) {
        items = newItems
        notifyDataSetChanged()
    }
}
