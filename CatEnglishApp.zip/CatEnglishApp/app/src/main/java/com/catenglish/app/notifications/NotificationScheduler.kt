package com.catenglish.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.data.ConfigEntity
import com.catenglish.app.data.ConfigKeys
import java.util.Calendar

/**
 * Owns scheduling of exactly two local notifications per day:
 *   SESSION_MORNING -> "Acquisition" (30 min learning session)
 *   SESSION_EVENING -> "Daily mini-exam" (25 min, spaced repetition)
 *
 * Times are fully configurable from the password-protected Admin Panel and
 * persisted in the local `config` table (no network involved at any point).
 */
class NotificationScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    suspend fun rescheduleFromStoredConfig() {
        val db = (context.applicationContext as CatEnglishApplication).database
        val configDao = db.configDao()

        val morningHour = configDao.getValue(ConfigKeys.NOTIF_MORNING_HOUR)?.toIntOrNull()
            ?: ConfigKeys.DEFAULT_MORNING_HOUR
        val morningMinute = configDao.getValue(ConfigKeys.NOTIF_MORNING_MINUTE)?.toIntOrNull()
            ?: ConfigKeys.DEFAULT_MORNING_MINUTE
        val eveningHour = configDao.getValue(ConfigKeys.NOTIF_EVENING_HOUR)?.toIntOrNull()
            ?: ConfigKeys.DEFAULT_EVENING_HOUR
        val eveningMinute = configDao.getValue(ConfigKeys.NOTIF_EVENING_MINUTE)?.toIntOrNull()
            ?: ConfigKeys.DEFAULT_EVENING_MINUTE

        scheduleDaily(REQUEST_CODE_MORNING, morningHour, morningMinute, NotificationReceiver.TYPE_MORNING)
        scheduleDaily(REQUEST_CODE_EVENING, eveningHour, eveningMinute, NotificationReceiver.TYPE_EVENING)
    }

    /** Called by the Admin Panel when times are changed. Persists + reschedules immediately. */
    suspend fun updateTimes(morningHour: Int, morningMinute: Int, eveningHour: Int, eveningMinute: Int) {
        val db = (context.applicationContext as CatEnglishApplication).database
        val configDao = db.configDao()
        configDao.set(ConfigEntity(ConfigKeys.NOTIF_MORNING_HOUR, morningHour.toString()))
        configDao.set(ConfigEntity(ConfigKeys.NOTIF_MORNING_MINUTE, morningMinute.toString()))
        configDao.set(ConfigEntity(ConfigKeys.NOTIF_EVENING_HOUR, eveningHour.toString()))
        configDao.set(ConfigEntity(ConfigKeys.NOTIF_EVENING_MINUTE, eveningMinute.toString()))
        rescheduleFromStoredConfig()
    }

    private fun scheduleDaily(requestCode: Int, hour: Int, minute: Int, type: String) {
        val triggerAt = nextTriggerTime(hour, minute)

        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(NotificationReceiver.EXTRA_TYPE, type)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.cancel(pendingIntent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            // Fallback: inexact repeating alarm if the user hasn't granted exact-alarm permission.
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP, triggerAt, AlarmManager.INTERVAL_DAY, pendingIntent
            )
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    private fun nextTriggerTime(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (target.timeIntervalIsPast(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    private fun Calendar.timeIntervalIsPast(now: Calendar): Boolean = this.before(now)

    companion object {
        private const val REQUEST_CODE_MORNING = 1001
        private const val REQUEST_CODE_EVENING = 1002
    }
}
