package com.catenglish.app.learning

import com.catenglish.app.data.AppDatabase
import com.catenglish.app.data.ConfigEntity
import com.catenglish.app.data.ConfigKeys

/**
 * Owns the 10-day program state machine:
 *  - tracks `current_day` (1..10)
 *  - advances the day after Session 2 (evening mini-exam) is completed
 *  - unlocks "Główny Boss" only once day 10 has been reached/completed
 *  - carries mistaken verbs forward into the next day's remedial pool (via needsRemedial flag)
 */
class DailyPlanManager(private val db: AppDatabase) {

    suspend fun getCurrentDay(): Int {
        return db.configDao().getValue(ConfigKeys.CURRENT_DAY)?.toIntOrNull() ?: 1
    }

    suspend fun isBossUnlocked(): Boolean {
        val day = getCurrentDay()
        val flag = db.configDao().getValue(ConfigKeys.BOSS_UNLOCKED) == "true"
        return flag || day >= 10
    }

    /** Call once Session 2 (evening mini-exam) has been completed for the current day. */
    suspend fun advanceDayIfEligible() {
        val day = getCurrentDay()
        if (day < 10) {
            db.configDao().set(ConfigEntity(ConfigKeys.CURRENT_DAY, (day + 1).toString()))
        } else {
            db.configDao().set(ConfigEntity(ConfigKeys.BOSS_UNLOCKED, "true"))
        }
    }

    suspend fun todaysNewVerbCount(): Int {
        val day = getCurrentDay()
        return db.verbDao().getByAssignedDay(day).size
    }

    suspend fun daysRemainingUntilBoss(): Int {
        val day = getCurrentDay()
        return (10 - day).coerceAtLeast(0)
    }
}
