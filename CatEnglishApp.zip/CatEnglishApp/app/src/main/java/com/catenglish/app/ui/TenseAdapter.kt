package com.catenglish.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.catenglish.app.databinding.ItemTenseBinding

class TenseAdapter(private val items: List<GrammarTense>) :
    RecyclerView.Adapter<TenseAdapter.VH>() {

    inner class VH(val binding: ItemTenseBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemTenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val tense = items[position]
        holder.binding.tenseName.text = tense.name
        holder.binding.tenseFormula.text = "Wzór: ${tense.formula}"
        holder.binding.tenseExample.text = tense.example
        holder.binding.tenseUsage.text = tense.usage
    }

    override fun getItemCount() = items.size
}
