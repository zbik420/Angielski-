package com.catenglish.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(progress: List<UserProgressEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(progress: UserProgressEntity)

    @Update
    suspend fun update(progress: UserProgressEntity)

    @Query("SELECT * FROM user_progress WHERE verbId = :verbId LIMIT 1")
    suspend fun getForVerb(verbId: Int): UserProgressEntity?

    @Query("SELECT * FROM user_progress")
    suspend fun getAll(): List<UserProgressEntity>

    @Query("SELECT * FROM user_progress")
    fun observeAll(): Flow<List<UserProgressEntity>>

    @Query("SELECT * FROM user_progress WHERE needsRemedial = 1")
    suspend fun getRemedialPool(): List<UserProgressEntity>

    @Query("SELECT * FROM user_progress WHERE introducedOnDay > 0 AND introducedOnDay < :day")
    suspend fun getReviewCandidates(day: Int): List<UserProgressEntity>

    @Query("SELECT COUNT(*) FROM user_progress WHERE isMastered = 1")
    suspend fun countMastered(): Int

    @Query("SELECT COUNT(*) FROM user_progress")
    suspend fun countTracked(): Int

    @Query("UPDATE user_progress SET needsRemedial = 0")
    suspend fun clearAllRemedialFlags()

    /**
     * Global retention percentage shown on the main screen's cat graphic.
     * = average mastery score across all 150 verbs (untouched verbs count as 0).
     */
    @Query("SELECT COALESCE(SUM(masteryScore), 0) FROM user_progress")
    suspend fun sumMastery(): Int
}
