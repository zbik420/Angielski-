package com.catenglish.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Per-verb learning record. This is the backbone of the spaced-repetition engine.
 *
 * masteryScore: 0..100, increments/decrements based on quiz answers.
 * consecutiveCorrect: streak counter used to decide when a verb is "mastered" (>= MASTERY_THRESHOLD).
 * lastReviewedEpochDay: used to compute which verbs are "due" for cross-testing.
 * timesWrong: pushes the verb back into the next day's remedial pool when > 0 on exam day.
 */
@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val verbId: Int,
    val masteryScore: Int = 0,
    val consecutiveCorrect: Int = 0,
    val timesSeen: Int = 0,
    val timesWrong: Int = 0,
    val lastReviewedEpochDay: Long = 0L,
    val introducedOnDay: Int = 0,
    val isMastered: Boolean = false,
    val needsRemedial: Boolean = false
) {
    companion object {
        const val MASTERY_THRESHOLD = 90
    }
}
