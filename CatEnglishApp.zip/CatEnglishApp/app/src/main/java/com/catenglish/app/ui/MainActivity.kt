package com.catenglish.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.R
import com.catenglish.app.admin.AdminLoginActivity
import com.catenglish.app.databinding.ActivityMainBinding
import com.catenglish.app.learning.DailyPlanManager
import com.catenglish.app.learning.QuizEngine
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val db by lazy { (application as CatEnglishApplication).database }
    private val quizEngine by lazy { QuizEngine(db) }
    private val planManager by lazy { DailyPlanManager(db) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.grammarButton.setOnClickListener {
            startActivity(Intent(this, GrammarActivity::class.java))
        }
        binding.dictionaryButton.setOnClickListener {
            startActivity(Intent(this, DictionaryActivity::class.java))
        }
        binding.sessionButton.setOnClickListener {
            startActivity(Intent(this, LearningSessionActivity::class.java))
        }
        binding.bossButton.setOnClickListener {
            lifecycleScope.launch {
                if (planManager.isBossUnlocked()) {
                    startActivity(Intent(this@MainActivity, BossExamActivity::class.java))
                } else {
                    Toast.makeText(this@MainActivity, getString(R.string.boss_locked), Toast.LENGTH_SHORT).show()
                }
            }
        }
        binding.adminEntryText.setOnClickListener {
            startActivity(Intent(this, AdminLoginActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    private fun refreshState() {
        lifecycleScope.launch {
            val day = planManager.getCurrentDay()
            val bossUnlocked = planManager.isBossUnlocked()
            val retention = quizEngine.globalRetentionPercent()

            binding.dayLabel.text = "Dzień $day z 10"
            binding.retentionProgressBar.progress = retention
            binding.retentionPercentLabel.text = "$retention% opanowanego materiału"
            binding.catProgressImage.setImageResource(catStageDrawable(retention))

            binding.bossButton.isEnabled = bossUnlocked
            binding.bossButton.alpha = if (bossUnlocked) 1f else 0.5f
            binding.bossLockLabel.text = if (bossUnlocked) "Gotowy do walki!" else getString(R.string.boss_locked)
        }
    }

    private fun catStageDrawable(retentionPercent: Int): Int = when {
        retentionPercent >= 90 -> R.drawable.cat_stage_4
        retentionPercent >= 51 -> R.drawable.cat_stage_3
        retentionPercent >= 26 -> R.drawable.cat_stage_2
        else -> R.drawable.cat_stage_1
    }
}
