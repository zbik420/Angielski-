package com.catenglish.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.data.AppDatabase
import com.catenglish.app.data.DatabaseSeeder
import com.catenglish.app.notifications.NotificationScheduler
import kotlinx.coroutines.launch

/**
 * Root Application class.
 *
 * Responsibilities on cold start:
 *  1. Open/create the local Room database (no network involved).
 *  2. Seed the 150 verbs from assets/verbs.json exactly once.
 *  3. Create the notification channel.
 *  4. Ensure the two daily AlarmManager/WorkManager notifications are scheduled,
 *     using whatever times are stored in local config (defaults 08:00 / 20:00).
 */
class CatEnglishApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        ProcessLifecycleOwner.get().lifecycleScope.launch {
            DatabaseSeeder(this@CatEnglishApplication, database).seedIfNeeded()
            NotificationScheduler(this@CatEnglishApplication).rescheduleFromStoredConfig()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kocie Czasowniki - Przypomnienia",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Powiadomienia o sesjach nauki i egzaminach"
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "cat_english_sessions"
    }
}
