package com.catenglish.app.admin

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.data.ConfigEntity
import com.catenglish.app.data.ConfigKeys
import com.catenglish.app.databinding.ActivityAdminLoginBinding
import com.catenglish.app.util.PasswordHasher
import kotlinx.coroutines.launch

/**
 * Password-protected gate in front of the Admin Panel.
 * First run: no password is set yet -> user is prompted to CREATE one (stored hashed, locally).
 * Subsequent runs: user must enter the correct password to proceed.
 */
class AdminLoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminLoginBinding
    private val db by lazy { (application as CatEnglishApplication).database }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lifecycleScope.launch {
            val existingHash = db.configDao().getValue(ConfigKeys.ADMIN_PASSWORD_HASH)
            binding.subtitle.text = if (existingHash == null)
                "Ustaw hasło administratora (pierwsze uruchomienie)"
            else
                "Podaj hasło administratora"
        }

        binding.submitButton.setOnClickListener {
            val entered = binding.passwordInput.text?.toString().orEmpty()
            if (entered.length < 4) {
                Toast.makeText(this, "Hasło musi mieć min. 4 znaki", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val existingHash = db.configDao().getValue(ConfigKeys.ADMIN_PASSWORD_HASH)
                if (existingHash == null) {
                    db.configDao().set(ConfigEntity(ConfigKeys.ADMIN_PASSWORD_HASH, PasswordHasher.hash(entered)))
                    openPanel()
                } else if (PasswordHasher.verify(entered, existingHash)) {
                    openPanel()
                } else {
                    Toast.makeText(this@AdminLoginActivity, getString(com.catenglish.app.R.string.admin_wrong_password), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openPanel() {
        startActivity(Intent(this, AdminPanelActivity::class.java))
        finish()
    }
}
