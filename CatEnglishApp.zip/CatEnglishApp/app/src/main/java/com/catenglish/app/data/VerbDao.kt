package com.catenglish.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VerbDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(verbs: List<VerbEntity>)

    @Query("SELECT COUNT(*) FROM verbs")
    suspend fun count(): Int

    @Query("SELECT * FROM verbs ORDER BY id ASC")
    fun observeAll(): Flow<List<VerbEntity>>

    @Query("SELECT * FROM verbs ORDER BY id ASC")
    suspend fun getAll(): List<VerbEntity>

    @Query("SELECT * FROM verbs WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): VerbEntity?

    @Query("SELECT * FROM verbs WHERE `group` = :group ORDER BY id ASC")
    suspend fun getByGroup(group: String): List<VerbEntity>

    @Query("SELECT * FROM verbs WHERE assignedDay = :day ORDER BY id ASC")
    suspend fun getByAssignedDay(day: Int): List<VerbEntity>

    @Query("SELECT * FROM verbs WHERE assignedDay <= :day AND assignedDay > 0 ORDER BY id ASC")
    suspend fun getAllUpToDay(day: Int): List<VerbEntity>

    @Update
    suspend fun update(verb: VerbEntity)

    @Update
    suspend fun updateAll(verbs: List<VerbEntity>)

    @Query("SELECT * FROM verbs WHERE base LIKE '%' || :query || '%' OR polish LIKE '%' || :query || '%' ORDER BY id ASC")
    suspend fun search(query: String): List<VerbEntity>
}
