package com.catenglish.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.catenglish.app.databinding.ActivityGrammarBinding

class GrammarActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGrammarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGrammarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tensesRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.tensesRecyclerView.adapter = TenseAdapter(GrammarData.tenses)
    }
}
