package com.catenglish.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AlarmManager exact alarms are cleared on reboot. This receiver re-arms both
 * daily notifications from the locally stored config as soon as the device
 * boots back up — no network or server involved.
 */
class BootRescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                NotificationScheduler(context.applicationContext).rescheduleFromStoredConfig()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
