package com.catenglish.app.ui

data class GrammarTense(
    val name: String,
    val formula: String,
    val example: String,
    val usage: String
)

/** Fully static, offline cheat-sheet data for the 4 basic tenses required by the spec. */
object GrammarData {
    val tenses = listOf(
        GrammarTense(
            name = "Present Simple",
            formula = "podmiot + czasownik (+s/es dla 3os.lp) / do not + czasownik",
            example = "She works every day. / She does not work on Sundays.",
            usage = "Czynności rutynowe, fakty, harmonogramy, prawdy ogólne."
        ),
        GrammarTense(
            name = "Present Continuous",
            formula = "podmiot + am/is/are + czasownik-ing",
            example = "I am learning irregular verbs right now.",
            usage = "Czynności trwające w chwili mówienia, plany na najbliższą przyszłość."
        ),
        GrammarTense(
            name = "Past Simple",
            formula = "podmiot + czasownik w II formie (regularny: +ed / nieregularny: II forma)",
            example = "I swam in the lake yesterday.",
            usage = "Zakończone czynności w przeszłości, w konkretnym momencie."
        ),
        GrammarTense(
            name = "Future Simple",
            formula = "podmiot + will + czasownik (forma podstawowa)",
            example = "I will master all 150 verbs by day 10.",
            usage = "Przewidywania, decyzje podjęte w chwili mówienia, obietnice."
        )
    )
}
