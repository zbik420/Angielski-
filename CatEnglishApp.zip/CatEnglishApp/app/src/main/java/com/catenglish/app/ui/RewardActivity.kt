package com.catenglish.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.R
import com.catenglish.app.audio.AudioPlayer
import com.catenglish.app.databinding.ActivityRewardBinding
import com.catenglish.app.learning.MotivationSlogans
import kotlinx.coroutines.launch

/**
 * Two reward states, per spec:
 *  - Daily mini-exam PASS  -> street-style motivational slogan + looped local reward track.
 *  - Główny Boss PASS (>=90%) -> victory screen + local victory track.
 *  - Any FAIL -> encouraging (non-punishing) message, no music, verbs pushed to remedial pool.
 */
class RewardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRewardBinding
    private lateinit var audioPlayer: AudioPlayer
    private val db by lazy { (application as CatEnglishApplication).database }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRewardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        audioPlayer = AudioPlayer(this)

        val correct = intent.getIntExtra(EXTRA_CORRECT, 0)
        val total = intent.getIntExtra(EXTRA_TOTAL, 0)
        val passed = intent.getBooleanExtra(EXTRA_PASSED, false)
        val isBoss = intent.getBooleanExtra(EXTRA_IS_BOSS, false)

        binding.rewardScoreText.text = "Wynik: $correct / $total"

        when {
            isBoss && passed -> showBossVictory()
            isBoss && !passed -> showBossRetry()
            passed -> showDailySuccess()
            else -> showDailyRetry()
        }

        binding.continueButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            })
            finish()
        }
    }

    private fun showDailySuccess() {
        binding.rewardTitle.text = getString(R.string.exam_passed_title)
        binding.rewardCatImage.setImageResource(R.drawable.cat_stage_3)
        lifecycleScope.launch {
            val streetMode = db.configDao().getValue("street_slogans_enabled")?.toBooleanStrictOrNull() ?: true
            binding.rewardSloganText.text = MotivationSlogans.random(streetMode)
        }
        audioPlayer.playDailyRewardTrack()
    }

    private fun showDailyRetry() {
        binding.rewardTitle.text = "Prawie! Spróbuj ponownie jutro"
        binding.rewardCatImage.setImageResource(R.drawable.cat_stage_2)
        binding.rewardSloganText.text =
            "Pomylone czasowniki wracają do powtórki jutro. Systematyczność wygrywa!"
    }

    private fun showBossVictory() {
        binding.rewardTitle.text = getString(R.string.boss_victory_title)
        binding.rewardCatImage.setImageResource(R.drawable.cat_stage_4)
        binding.rewardSloganText.text = "150 czasowników opanowanych. Jesteś mistrzem! 🏆🐱"
        audioPlayer.playBossVictoryTrack()
    }

    private fun showBossRetry() {
        binding.rewardTitle.text = "Boss jeszcze niepokonany"
        binding.rewardCatImage.setImageResource(R.drawable.cat_stage_3)
        binding.rewardSloganText.text = "Potrzeba min. 90% do zwycięstwa. Powtórz materiał i spróbuj ponownie!"
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }

    companion object {
        const val EXTRA_CORRECT = "extra_correct"
        const val EXTRA_TOTAL = "extra_total"
        const val EXTRA_PASSED = "extra_passed"
        const val EXTRA_IS_BOSS = "extra_is_boss"
    }
}
