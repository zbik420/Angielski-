package com.catenglish.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Simple local key-value config store. Used for:
 *  - "notif_morning_hour", "notif_morning_minute"
 *  - "notif_evening_hour", "notif_evening_minute"
 *  - "admin_password_hash"
 *  - "current_day"            (1..10, the current position in the 10-day plan)
 *  - "boss_unlocked"          ("true"/"false")
 *  - "program_start_epoch_day"
 */
@Entity(tableName = "config")
data class ConfigEntity(
    @PrimaryKey val key: String,
    val value: String
)

object ConfigKeys {
    const val NOTIF_MORNING_HOUR = "notif_morning_hour"
    const val NOTIF_MORNING_MINUTE = "notif_morning_minute"
    const val NOTIF_EVENING_HOUR = "notif_evening_hour"
    const val NOTIF_EVENING_MINUTE = "notif_evening_minute"
    const val ADMIN_PASSWORD_HASH = "admin_password_hash"
    const val CURRENT_DAY = "current_day"
    const val BOSS_UNLOCKED = "boss_unlocked"
    const val PROGRAM_START_EPOCH_DAY = "program_start_epoch_day"
    const val DB_SEEDED = "db_seeded"

    // Sensible defaults per spec: Session 1 morning, Session 2 evening
    const val DEFAULT_MORNING_HOUR = 8
    const val DEFAULT_MORNING_MINUTE = 0
    const val DEFAULT_EVENING_HOUR = 20
    const val DEFAULT_EVENING_MINUTE = 0
}
