package com.catenglish.app.notifications

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.catenglish.app.CatEnglishApplication
import com.catenglish.app.R
import com.catenglish.app.ui.LearningSessionActivity
import com.catenglish.app.ui.ExamActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fires exactly twice a day (times configured in the Admin Panel):
 *   TYPE_MORNING -> deep-links into the Acquisition session (Session 1)
 *   TYPE_EVENING -> deep-links into the Daily Mini-Exam (Session 2)
 *
 * After firing, it re-arms itself for the following day so the schedule is
 * self-sustaining without any server / push infrastructure.
 */
class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(EXTRA_TYPE) ?: return
        val pendingResult = goAsync()

        showNotification(context, type)

        // Re-arm tomorrow's alarm using the currently stored config (handles admin edits too).
        CoroutineScope(Dispatchers.IO).launch {
            try {
                NotificationScheduler(context.applicationContext).rescheduleFromStoredConfig()
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(context: Context, type: String) {
        val isMorning = type == TYPE_MORNING
        val targetActivity = if (isMorning) LearningSessionActivity::class.java else ExamActivity::class.java

        val contentIntent = Intent(context, targetActivity).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            if (isMorning) 2001 else 2002,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isMorning)
            context.getString(R.string.notification_morning_title)
        else
            context.getString(R.string.notification_evening_title)

        val text = if (isMorning)
            "Twoje dzisiejsze koty czekają na nowe czasowniki. 30 minut, dasz radę! 🐾"
        else
            "Czas na mini-egzamin dnia + powtórki. 25 minut do mistrzostwa! 🏆"

        val notification = NotificationCompat.Builder(context, CatEnglishApplication.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_cat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = if (isMorning) 3001 else 3002
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        ) {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        }
    }

    companion object {
        const val EXTRA_TYPE = "extra_type"
        const val TYPE_MORNING = "morning"
        const val TYPE_EVENING = "evening"
    }
}
